#include <iostream>
#include <string.h>
#include <cstring>
#include "class.h"
using namespace std;  


int main() {
    Fraction f1;
    f1.input("1/2");
    
    f1.output();
   
   
  
  
  
  return 0;
}
